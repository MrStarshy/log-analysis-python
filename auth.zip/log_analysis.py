import pandas as pd
import re

# Step 1: Read the log file
logfile = "auth.log"  # Make sure this file is in the same folder
failed_ips = []

# Step 2: Extract failed login IPs using regex
with open(logfile, "r") as file:
    for line in file:
        if "Failed password" in line:
            match = re.search(r'from (\d+\.\d+\.\d+\.\d+)', line)
            if match:
                failed_ips.append(match.group(1))

# Step 3: Load data into pandas and summarize
df = pd.DataFrame(failed_ips, columns=["IP"])
print("Top IPs with Failed Logins:")
print(df["IP"].value_counts())